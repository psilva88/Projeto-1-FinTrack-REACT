const { gql } = require('graphql-tag');

const Pessoa = require('../models/Pessoa');

const typeDefs = gql`

    type Pessoa {
        id: ID!
        nome: String!
        email: String!
        idade: Int!
    }

    type Usuario {
        id: ID!
        nome: String!
        email: String!
        perfil: String!
    }

    type Query {
        pessoas: [Pessoa!]!
        pessoa(id: ID!): Pessoa
    }

    type Mutation {
        cadastrarPessoa(
            nome: String!
            email: String!
            idade: Int!
        ): Pessoa!

        excluirPessoa(id: ID!): String!
    }

`;

const resolvers = {

    Query: {

        pessoas: async (_, args, context) => {

            if (!context.usuario) {
                throw new Error(
                    'Usuário não autenticado'
                );
            }

            return await Pessoa.find();
        },

        pessoa: async (_, { id }, context) => {

            if (!context.usuario) {
                throw new Error(
                    'Usuário não autenticado'
                );
            }

            return await Pessoa.findById(id);
        }

    },

    Mutation: {

        cadastrarPessoa: async (
            _,
            { nome, email, idade },
            context
        ) => {

            if (!context.usuario) {
                throw new Error(
                    'Usuário não autenticado'
                );
            }

            const pessoa = new Pessoa({
                nome,
                email,
                idade
            });

            return await pessoa.save();
        },

        excluirPessoa: async (_, { id }, context) => {

            if (!context.usuario) {
                throw new Error(
                    'Usuário não autenticado'
                );
            }

            if (context.usuario.perfil !== 'admin') {
                throw new Error(
                    'Usuário não possui permissão'
                );
            }

            const pessoa =
                await Pessoa.findByIdAndDelete(id);

            if (!pessoa) {
                throw new Error(
                    'Pessoa não encontrada'
                );
            }

            return 'Pessoa excluída com sucesso';
        }

    }

};

module.exports = {
    typeDefs,
    resolvers
};
