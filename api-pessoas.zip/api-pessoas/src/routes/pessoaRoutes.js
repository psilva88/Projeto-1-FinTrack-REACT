const express = require('express');

const {
    cadastrarPessoa,
    listarPessoas,
    excluirPessoa
} = require('../controllers/pessoaController');

const {
    autenticar,
    autorizar
} = require('../middlewares/authMiddleware');

const router = express.Router();

router.post(
    '/pessoas',
    autenticar,
    cadastrarPessoa
);

router.get(
    '/pessoas',
    autenticar,
    listarPessoas
);

router.delete(
    '/pessoas/:id',
    autenticar,
    autorizar('admin'),
    excluirPessoa
);

module.exports = router;
