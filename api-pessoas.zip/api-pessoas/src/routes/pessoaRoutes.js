const express = require('express');

const router = express.Router();

const {
    cadastrarPessoa,
    listarPessoas,
} = require('../controllers/pessoaController');

router.post('/pessoas', cadastrarPessoa);

router.get('/pessoas', listarPessoas);

module.exports = router;
