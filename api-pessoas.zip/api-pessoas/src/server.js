require('dotenv').config();

const express = require('express');

const conectarBanco = require('./database');

const pessoaRoutes = require('./routes/pessoaRoutes');

const app = express();

app.use(express.json());

conectarBanco();

app.use(pessoaRoutes);

const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`);
});
