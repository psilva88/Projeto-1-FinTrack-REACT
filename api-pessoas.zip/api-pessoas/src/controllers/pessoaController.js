const Pessoa = require('../models/Pessoa');

const cadastrarPessoa = async (req, res) => {
    try {
        const pessoa = new Pessoa({
            nome: req.body.nome,
            email: req.body.email,
            idade: req.body.idade
        });

        const pessoaSalva = await pessoa.save();

        res.status(201).json(pessoaSalva);

    } catch (error) {
        res.status(500).json({
            mensagem: 'Erro ao cadastrar pessoa',
            erro: error.message
        });
    }
};

const listarPessoas = async (req, res) => {
    try {
        const pessoas = await Pessoa.find();

        res.status(200).json(pessoas);

    } catch (error) {
        res.status(500).json({
            mensagem: 'Erro ao buscar pessoas',
            erro: error.message
        });
    }
};

module.exports = {
    cadastrarPessoa,
    listarPessoas
};
